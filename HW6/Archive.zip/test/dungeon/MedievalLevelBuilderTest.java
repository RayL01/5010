package dungeon;

import static org.junit.Assert.*;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: shadyyyyyl
 * @Date: 2022/11/28/22:36
 * @Description:
 */
public class MedievalLevelBuilderTest {

}