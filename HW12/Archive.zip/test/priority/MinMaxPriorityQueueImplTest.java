package priority;

import static org.junit.Assert.*;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: shadyyyyyl
 * @Date: 2022/12/04/20:23
 * @Description:
 */
public class MinMaxPriorityQueueImplTest {

  @org.junit.Test
  public void add() {
  }

  @org.junit.Test
  public void minPriorityItem() {
  }

  @org.junit.Test
  public void maxPriorityItem() {
  }

  @org.junit.Test
  public void sizeofMaxHeap() {
  }

  @org.junit.Test
  public void sizeofMinHeap() {
  }
}